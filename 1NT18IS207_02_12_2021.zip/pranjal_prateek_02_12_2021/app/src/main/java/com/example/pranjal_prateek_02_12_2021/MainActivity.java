package com.example.pranjal_prateek_02_12_2021;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button play,pause,forward,stop,rewind,restart;
    MediaPlayer mediaPlayer;
    int starttime=0;
    int stoptime=0;
    int forwardtime=5000;
    int backwardtime=5000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        play=findViewById(R.id.play);
        pause=findViewById(R.id.pause);
        forward=findViewById(R.id.forward);
        stop=findViewById(R.id.stop);
        rewind=findViewById(R.id.rewind);
        restart=findViewById(R.id.restart);

        TextView t1=findViewById(R.id.songname);

        mediaPlayer=MediaPlayer.create(this,R.raw.doremon);
        t1.setText("Doremon");
       play.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Toast.makeText(MainActivity.this, "Play song", Toast.LENGTH_SHORT).show();
               mediaPlayer.start();
           }
       });
       stop.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Toast.makeText(MainActivity.this, "stopping song", Toast.LENGTH_SHORT).show();
               mediaPlayer.stop();
           }
       });
       pause.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Toast.makeText(MainActivity.this, "Pausing song", Toast.LENGTH_SHORT).show();
               mediaPlayer.pause();
           }
       });
       restart.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Toast.makeText(MainActivity.this,"restarting",Toast.LENGTH_SHORT).show();
               int currpos=mediaPlayer.getCurrentPosition();
               mediaPlayer.seekTo(currpos-currpos);
           }
       });
        forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentpos = mediaPlayer.getCurrentPosition() ;
                if((currentpos+forwardtime) <= (stoptime =
                        mediaPlayer.getDuration())){
                    mediaPlayer.seekTo(currentpos+forwardtime);
                }
            }
        });
        rewind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currpos= mediaPlayer.getCurrentPosition();
                if((currpos-backwardtime)>=(starttime)){
                    mediaPlayer.seekTo(currpos-backwardtime);
                }
            }
        });

    }
}