package com.example.pranjal_25_11_21;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    boolean isNewOp=true;
    EditText ed1;
    String oldNumber = ed1.getText().toString();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.editText);
    }
    public void numberEvent(View view)
    {
        if(isNewOp)
            ed1.setText("");
        isNewOp=false;
        String number=ed1.getText().toString();
        switch (view.getId()){
            case R.id.buone:
                number+="1";
                break;
            case R.id.butwo:
                number+="2";
                break;
            case R.id.buthree:
                number+="3";
                break;
            case R.id.bufour:
                number+="4";
                break;
            case R.id.bufive:
                number+="5";
                break;
            case R.id.busix:
                number+=6;
                break;
            case R.id.buseven:
                number+="7";
                break;
            case R.id.bueight:
                number+="8";
                break;
            case R.id.bunine:
                number+="9";
                break;
            case R.id.buzero:
                number+="0";
                break;
            case R.id.buzerozero:
                number+="00";
                break;
            case R.id.bumul:
                number+="*";
                break;
            case R.id.budiv:
                number+="/";
                break;
            case R.id.buplusminus:
                number+="+/-";
                break;

        }
        ed1.setText(number);
    }
    public void operatorEvent(View view){
        isNewOp=true;

        String op=ed1.getText().toString();
        switch(view.getId()){
            case R.id.budivide:
                op="/";
                break;
            case R.id.bumul:
                op="*";
                break;
            case R.id.buplus:
                op="+";
                break;
            case  R.id.buminus:
                op="-";
                break;
        }
    }
    public void equalEvent(View view){
        String newNumber=ed1.getText().toString();
        double result=0.0;
        int op;
        switch(op){
            case "+":
                result=Double.parseDouble(oldNumber)+Double.parseDouble(newNumber);
                break;
            case "-":
                result=Double.parseDouble(oldNumber)+Double.parseDouble(newNumber);
                break;
            case "*":
                result=Double.parseDouble(oldNumber)+Double.parseDouble(newNumber);
                break;
            case "/":
                result=Double.parseDouble(oldNumber)+Double.parseDouble(newNumber);
        }
        ed1.setText((int) result);
    }
}