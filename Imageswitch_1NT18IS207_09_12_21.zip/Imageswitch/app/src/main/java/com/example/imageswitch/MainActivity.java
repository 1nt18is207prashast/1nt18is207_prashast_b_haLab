package com.example.imageswitch;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button b1;
    ImageView i1;
    int i=0;

    int img[]={R.drawable.pups,R.drawable.imhg,R.drawable.lep};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         b1=findViewById(R.id.button);
         i1=findViewById(R.id.imageView);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i1.setImageResource(img[i]);
                i++;
                if(i==3)
                {
                    i=0;
                }
            }
        });
    }
}