package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(getApplicationContext(),"Hello my users",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(getApplicationContext(),"Tata Bye Bye Khtm",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        Button add=(Button) findViewById(R.id.add);
//        num1=(EditText) findViewById(R.id.textView2);
//        num2=(EditText) findViewById(R.id.textView3);
//        resu=(TextView) findViewById(R.id.textView);
        Button add=(Button) findViewById(R.id.button);


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText number1=(EditText) findViewById(R.id.textView2);
                EditText number2=(EditText) findViewById(R.id.textView3);
                TextView resu=(TextView) findViewById(R.id.textView);
                int a=Integer.parseInt(number1.getText().toString());
                int b=Integer.parseInt(number2.getText().toString());
                int sum=a+b;

                resu.setText(Integer.toString(sum));
            }
        });

    }
}